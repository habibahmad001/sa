<!-- footer content -->
<footer>
<div class="pull-right">
    Super Admin Panel
</div>
<div class="clearfix"></div>
</footer>
<!-- /footer content -->
