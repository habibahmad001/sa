<?php 
session_start();
include_once('cms.php');
$objcms = new cms();

?>