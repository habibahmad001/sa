<?php 
include_once("classes/top.php");
/*
$col[] = "pdf_tit";        $val[] = "asdads";
$col[] = "img1";           $val[] = "asdads";
$col[] = "img2";           $val[] = "asdads";
$col[] = "img3";           $val[] = "asdads";
$col[] = "pdf_tit_1";      $val[] = "asdads";
$col[] = "pdf_tit_2";      $val[] = "asdads";
$col[] = "pdf_tit_3";      $val[] = "asdads";
$col[] = "pdf_tit_4";      $val[] = "asdads";
/////////////////// INSERT //////////////////////
$objcms->insert_new('prs',$col,$val);
/////////////////// UPDATE //////////////////////
$col[] = "pdf_tit";         	 $val[] = "14.jpg";
$col[] = "img1";             	$val[] = "15.jpg";
$col[] = "img2";         		$val[] = "16.jpg";
$col[] = "img3";         		$val[] = "17.jpg";
$col[] = "pdf_tit_1";     		$val[] = "18.jpg";
$col[] = "pdf_tit_2";           $val[] = "19.jpg";
$col[] = "pdf_tit_3";      	    $val[] = "20.jpg";
$field[] = "pdf_tit_3";         $path[] = "images/headings/";
$field[] = "pdf_tit";     		$path[] = "images/headings/";
$field[] = "img1";         		$path[] = "images/headings/";
$field[] = "img2";         		$path[] = "images/headings/";
$field[] = "img3";        		$path[] = "images/headings/";
$field[] = "pdf_tit_1";         $path[] = "images/headings/";
$field[] = "pdf_tit_2";         $path[] = "images/headings/";
/////////////////// UPDATE //////////////////////
$objcms->update_img('prs',$col,$val,'id','16',$path,$field); // Send Parameter As Array. Both Fields And Path.
$objcms->update_img('prs',$col,$val,'id','16','images/headings/','pdf_tit_2'); // Send Parameter As Variable. Both Fields And Path.
$objcms->update_img('prs',$col,$val,'id','16','',''); // If Image Not Deleted.
/////////////////// UPDATE //////////////////////
/////////////////// DELETR //////////////////////
$field[] = "pdf_tit_3";         $path[] = "images/headings/";
$field[] = "pdf_tit";     		$path[] = "images/headings/";
$field[] = "img1";         		$path[] = "images/headings/";
$field[] = "img2";         		$path[] = "images/headings/";
$field[] = "img3";        		$path[] = "images/headings/";
$field[] = "pdf_tit_1";         $path[] = "images/headings/";
$field[] = "pdf_tit_2";         $path[] = "images/headings/";
/////////////////// DELETR //////////////////////
$objcms->delete_img('prs',$path,$field,'id','16');  // Send Parameter As Array. Both Fields And Path.
$objcms->delete_img('prs','images/headings/','pdf_tit_2','id','16'); // Send Parameter As Variable. Both Fields And Path.
$objcms->delete_img('prs','','','id','16');// If Image Not Deleted.
/////////////////// DELETR //////////////////////
*/
?>